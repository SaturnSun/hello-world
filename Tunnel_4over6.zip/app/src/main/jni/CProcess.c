#include "com_example_sun_tunnel_4over6_MyThread.h"
#include <android/log.h>

#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/socket.h>
#include <resolv.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/if.h>
#include <linux/if_tun.h>
#include <sys/types.h>
#include <net/route.h>
#include <pthread.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <time.h>
#include <sys/time.h>

#define  LOGD(...)  __android_log_print(ANDROID_LOG_DEBUG, "Cprocess", __VA_ARGS__)

#define MAXBUF 4096
#define V6PORT 5678
//#define V6IP "2402:f000:5:6c01:924c:e5ff:fee1:2199"
#define V6IP "2402:f000:1:4417::900"


const char* pipeTraffic= "/storage/sdcard0/traffic_to_foreground";
const char* pipeNetworkInfo = "/storage/sdcard0/info_to_foreground";// transfer info to foreground and tranfer tunfd to background

unsigned int recvLiveTime = 0;
int upTraffic = 0;
int upPacket = 0;
int downTraffic = 0;
int downPacket = 0;

int socketFd;
int tunFd=-1;
int trafficFd;
int infoFd;

struct Msg
{
    int length;
    char type;
    char data[MAXBUF];
};

void thread_timer()
{
    int counter=0;
    while(1)
    {
        //send traffic to foreground
        if((trafficFd = open(pipeTraffic,O_RDWR|O_CREAT|O_TRUNC))<0)
        {
            LOGD("open pipe traffic failed!%d %s\n",errno,strerror(errno));
        }
        char tmp[128]="";
        sprintf(tmp,"%d %d %d %d ",upPacket,downPacket,upTraffic,downTraffic);
        int size=0;
        if((size=write(trafficFd,tmp,strlen(tmp)))<0)
        {
            LOGD("Error in writing trafficFd!");
        }
        else
            close(trafficFd);
        //time exceed
        unsigned int now=time((time_t *)NULL);
        if(now-recvLiveTime>60)
        {
            close(socketFd);
            LOGD("Keeplive msg failed to be received before timeout.Close socket!");
        }

        if(counter==20)                //send keeplive msg
        {
            struct Msg livemsg;
            memset(&livemsg,0,sizeof(livemsg));
            livemsg.type=104;
            livemsg.length=5;
            if(send(socketFd,(char *)&livemsg,5,0)<0)
            {
                LOGD("Error in sending live msg!");
            }
            counter=0;
            LOGD("live message send!");
        }
        sleep(1);
        counter++;
    }
}

void thread_read_tun()
{
    struct Msg msg;
    memset(&msg,0,sizeof(msg));
    char buf[4096];
    while(1)
    {
        int size=read(tunFd,buf,sizeof(buf));
        //LOGD("read data from tun,size:%d\n",size);
        if(size>0)
        {
            LOGD("read data from tun,size:%d\n",size+5);
            msg.length=size+5;
            msg.type=102;
            memcpy(msg.data,buf,size);
            int ret=send(socketFd,(char *)&msg,size+5,0);
            if(ret<0)
            {
                LOGD("send to ipv6 server failed!");
            }
            if(msg.length>1400)
                LOGD("so long:%d send%d:\n",msg.length,ret);
            upPacket++;
            upTraffic+=size;
        }
    }
}

JNIEXPORT void JNICALL Java_com_example_sun_tunnel_14over6_MyThread_CProcess(JNIEnv * env, jobject obj)
{

    //socket init
    if((socketFd = socket(AF_INET6,SOCK_STREAM,0)) == -1) {
        LOGD("create socket failed!");
        exit(errno);
    }

    struct sockaddr_in6* serveraddr;
    serveraddr=(struct sockaddr_in6*)malloc(sizeof(struct sockaddr_in6));
    memset(serveraddr,0,sizeof(struct sockaddr_in6));
    serveraddr->sin6_family=AF_INET6;
    serveraddr->sin6_port=htons(V6PORT);
    if(inet_pton(AF_INET6,V6IP,&(serveraddr->sin6_addr))<0)
    {
        LOGD("error in changing ipv6 to network");
        return ;
    }

    //connect
    while(1)
    {
        if(connect(socketFd,(struct sockaddr *)serveraddr,sizeof(struct sockaddr_in6))==0)
        {
            LOGD("Successfully connect 4over6 server!");
            break;
        }
        else
        {
            LOGD("Connect 4over6 server failed!Try again!");
            sleep(5);
        }
    }
    //timer thread
    recvLiveTime = (int)time((time_t *)NULL);
    pthread_t id_timer;
    int ret;
    ret=pthread_create(&id_timer,NULL,(void *)thread_timer,NULL);
    if(ret!=0)
    {
        LOGD("timer thread create failed!");
    }
    //send ip request
    struct Msg ipReqMsg;
    ipReqMsg.type=100;
    ipReqMsg.length=5;
    while(send(socketFd,(char*)&ipReqMsg,ipReqMsg.length,0)<0)
    {
        LOGD("send ip request failed!Try again!");
        sleep(5);
    }
    LOGD("Successfully send ip request!");
    while(1)
    {
        char buf[MAXBUF];
        memset(&buf,0,sizeof(buf));
        int size=recv(socketFd,buf,MAXBUF,0);
        if(size>0)
        {
            struct Msg *msg;msg=(struct Msg*)buf;
            //LOGD("type:%d\n",msg->type);
            //LOGD("length:%d SIZE:%d\n",msg->length,size);//d
            msg->length=size;
            //msg->length=ntohl(msg->length);
            if(msg->type==101 && tunFd<0)
            {
                LOGD("101 received!");
                mknod(pipeNetworkInfo,S_IFIFO | 0666,0);//??
                if((infoFd=open(pipeNetworkInfo,O_RDWR|O_CREAT|O_TRUNC))<0)
                {
                    LOGD("open infotun failed!");
                }
                int ret;
                if((ret=write(infoFd,(char *)msg->data,msg->length-5))<0)
                {
                    LOGD("Error in writing info to foreground!");
                }
                else
                    close(infoFd);
                sleep(3);               //get tun fd from foreground
                while(1)
                {
                    sleep(1);
                    if((infoFd=open(pipeNetworkInfo,O_RDWR))<0)
                    {
                        LOGD("open infotun failed! 2");
                        continue;
                    }
                    memset(&buf,0,sizeof(buf));
                    size=read(infoFd,buf,100);
                    if(size<=0)
                    {
                        LOGD("read tunfd failed!");
                        close(infoFd);
                        continue;
                    }
                    else
                    {
                        close(infoFd);
                        break;
                    }
                }
                tunFd=atoi(buf);
                LOGD("tun %d\n",tunFd);
                pthread_t id_read_tun;
                if((pthread_create(&id_read_tun,NULL,(void *)thread_read_tun,NULL))!=0)
                    LOGD("fail to create thread_read_tun");
            }
            else if(msg->type==103 && msg->length-5>0)//response
            {
                //LOGD("103 received!");
                if((write(tunFd,msg->data,msg->length-5))==-1)
                    LOGD("write tunFd failed");
                //else
                //    LOGD("Successfully write tunFd");
                downPacket++;
                downTraffic+=msg->length-5;
            }
            else if(msg->type==104)
            {
                LOGD("104 received!");
                printf("recvtime:%d\n",recvLiveTime);
                unsigned int now=time((time_t*)NULL);
                if(now-recvLiveTime>60)
                    close(socketFd);
                else
                    recvLiveTime=now;
            }
            //free(msg);
        }
        else if(size==0)//network close
        {

            LOGD("close tun fd!");
            //erase pipe
            trafficFd=open(pipeTraffic,O_RDWR|O_CREAT|O_TRUNC);
            infoFd=open(pipeNetworkInfo,O_RDWR|O_CREAT|O_TRUNC);
            close(trafficFd);
            close(tunFd);
            close(infoFd);
            close(socketFd);
            pthread_exit((void*)0);
        }
    }
    return;
}