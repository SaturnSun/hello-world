package com.example.sun.tunnel_4over6;

import android.net.VpnService;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by Sun on 2016/2/12.
 */
public class MyVpnService extends VpnService{

   // private static final MyVpnService myVpnService = new MyVpnService();//单例模

    private String address;
    private String[] dns;
    private String route;
    //管道1：前台从管道1中读取到IP，路由和DNS信息，而后将安卓虚接口(tun0)描述符写入管道1
    public File file1 = new File( "/storage/sdcard0","info_to_foreground");//IP tun

    public void setAddress(String address) {
        this.address = address;
    }

    public void setDns(String[] dns) {
        this.dns = dns;
    }

    public void setRoute(String route) {
        this.route = route;
    }

    public boolean isVPNon = false;

    public void turnOn() {

        Builder builder=new Builder();
        builder.setMtu(1000);// <=1440 (1500 - 40(v6 header) - 20(tcp header))
        builder.addAddress(address, 16);
        builder.addRoute(route, 0);
        Log.d("debug", dns[0]);
        builder.addDnsServer(dns[0]); //hyoga why delete
        Log.d("debug", "ok1!");
        builder.addDnsServer(dns[1]);
        builder.addDnsServer(dns[2]);
        builder.addSearchDomain("");
        builder.setSession("4over6Tunnel");

        ParcelFileDescriptor tun0 = builder.establish();
        Log.d("debug","ok2!");
        if (tun0 != null){
            int tun0_fd = tun0.getFd();
            try {
                FileOutputStream fileOutputStream = new FileOutputStream(file1);
                BufferedOutputStream out = new BufferedOutputStream(fileOutputStream);
                String str = Integer.toString(tun0_fd);
                byte[] arr = str.getBytes();
                out.write(arr, 0, arr.length);//将虚接口描述符写入管道1
                out.close();//hyoga add
                Log.d("tunOpen",str);
                isVPNon = true;
            } catch (FileNotFoundException e){
                Log.d("fnf","File not found3");
            } catch (IOException e){
                Log.d("ioe", "io Exception");
            }
        }

    }

}
