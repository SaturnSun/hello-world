package com.example.sun.tunnel_4over6;

/**
 * Created by Sun on 2016/2/13.
 */
public class MyThread extends Thread {

    public void run(){
        //调用后台程序
        System.out.println("background program");
        CProcess();
    }
    public native void  CProcess();
    static {
        System.loadLibrary("cprocessJni");
    }
}
