package com.example.sun.tunnel_4over6;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.provider.Settings;
import android.content.Intent;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.TextView;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Timer;
import java.util.TimerTask;


public class MainActivity extends Activity {

    private boolean isNetworkOK = false;
    public static MyVpnService myVpnService =new MyVpnService();//hyoga change to public
    //定时任务
    private final Timer timer = new Timer();
    private TimerTask task;
    String nowtime;
    long duration;
    int hour;
    int min;
    int sec;
    //显示信息
    private TextView viewTime;
    private TextView viewUpSpeed;
    private TextView viewDownSpeed;
    private TextView viewUpTraffic;
    private TextView viewDownTraffic;
    private TextView viewIPv4addr;
    private TextView viewIPv6addr;

    SimpleDateFormat d = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private String startTime;
    private long upTraffic = 0;
    private long tmp_upTraffic = 0;
    private long downTraffic = 0;
    private long tmp_downTraffic = 0;
    private long upPacket = 0;
    private long downPacket = 0;
    private boolean vpnDialogFlag=false;
    private String ipv4_addr;
    private String ipv6_addr;
    //管道2：前台从管道2读取流量信息
    public File file2 = new File("/storage/sdcard0","traffic_to_foreground");//流量信息

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //绑定界面布局
        viewTime = (TextView)findViewById(R.id.timeView);
        viewUpSpeed = (TextView)findViewById(R.id.upSpeedView);
        viewDownSpeed = (TextView)findViewById(R.id.downSpeedView);
        viewUpTraffic = (TextView)findViewById(R.id.upTrafficView);
        viewDownTraffic = (TextView)findViewById(R.id.downTrafficView);
        viewIPv4addr = (TextView)findViewById(R.id.ipv4AddrView);
        viewIPv6addr = (TextView)findViewById(R.id.ipv6AddrView);

        //获取启动时间
        startTime = d.format(new Date());
        //初始化主界面
        showData();
        //进行网络检测并获取上联物理接口IPV6地址
        if (!isNetworkOK) {
            checkNetwork();
            ipv6_addr = getLocalIpAddress();
            Log.d("ipv6",ipv6_addr);
            isNetworkOK = true;
        }
        //-------hyoga--------start
        if (myVpnService.file1.exists())
            myVpnService.file1.delete();
        if (file2.exists())
            file2.delete();
        //------hyoga--------end
        //启动后台线程
        MyThread myThread = new MyThread();
        myThread.start();
        //设置定时任务

        task = new TimerTask() {
            @Override
            public void run() {
                    Message message = new Message();
                    message.what = 1;
                    handler.sendMessage(message);
            }
        };
        timer.schedule(task,1000,1000);

    }
    //定时任务具体内容：界面显示网络状态
    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg){
            switch (msg.what){
            case 1:
                if (myVpnService.isVPNon){//VPN已经开启，读取流量信息管道
                    try {
                        FileInputStream fileInputStream = new FileInputStream(file2);
                        BufferedInputStream in = new BufferedInputStream(fileInputStream);
                        byte[] buf = new byte[256];
                        int len = in.read(buf);
                        if (len > 0){
                            ByteArrayInputStream bais = new ByteArrayInputStream(buf);
                            DataInputStream dis = new DataInputStream(bais);
                            byte[] tmp1 = new byte[len];
                            dis.readFully(tmp1, 0, len);
                            String tmp2 = new String (tmp1, "UTF-8");
                            String[] traffic = new String[5];
                            traffic = tmp2.split(" ");//4个变量按照空格分开，取出来分别如下
                            upPacket = Long.parseLong(traffic[0]);
                            downPacket = Long.parseLong(traffic[1]);
                            tmp_upTraffic = upTraffic;
                            tmp_downTraffic = downTraffic;
                            upTraffic = Long.parseLong(traffic[2]);
                            downTraffic = Long.parseLong(traffic[3]);
                        }
                       // in.close();

                    } catch (FileNotFoundException e) {
                        Log.d("fnf", "File not found2");
                    } catch (IOException e){
                        Log.d("ioe", "IO Exception");
                    }
                }else if(!vpnDialogFlag){//读取IP管道
                    try {

                        if (!myVpnService.file1.exists()){
                            myVpnService.file1.createNewFile();
                        }
                        FileInputStream fileInputStream = new FileInputStream(myVpnService.file1);
                        BufferedInputStream in = new BufferedInputStream(fileInputStream);
                        byte[] buf = new byte[256];
                        int len = in.read(buf);
                        //判断有无IP等信息
                        if (len > 0){
                            //有：启用VPN服务；将安卓虚接口描述符写入管道，读取ip信息并显示
                            ByteArrayInputStream bais = new ByteArrayInputStream(buf);
                            DataInputStream dis = new DataInputStream(bais);
                            byte[] tmp1 = new byte[len];
                            dis.readFully(tmp1, 0, len);
                            String tmp2 = new String (tmp1, "UTF-8");
                            String[] ipinfo = new String[5];
                            ipinfo = tmp2.split(" ");
                            ipv4_addr = ipinfo[0];//服务器分配的ipv4地址
                            String route = ipinfo[1];//路由
                            String[] dns = {ipinfo[2],ipinfo[3],ipinfo[4]};//3个DNS
                            myVpnService.setAddress(ipv4_addr);
                            myVpnService.setDns(dns);
                            myVpnService.setRoute(route);
                            Log.d("vpn ipv4", ipv4_addr);
                            Log.d("vpn route", route);
                            Log.d("vpn dns", dns[0]);
                            openVPN();
                            vpnDialogFlag=true;
                            Log.d("vpn","vpn is open!");
                        }
                       // in.close();
                    } catch (FileNotFoundException e) {
                        System.out.println("File not found1");
                    } catch (IOException e){
                        Log.d("ioe", "IO Exception");
                    }
                }

                showData();
            break;
            default:break;
            }
            super.handleMessage(msg);
        }
    };
    //进行网络检测
    public boolean checkNetwork(){
        ConnectivityManager con=(ConnectivityManager)getSystemService(Activity.CONNECTIVITY_SERVICE);
        NetworkInfo activeMetwork = con.getActiveNetworkInfo();
        if (activeMetwork == null) {
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("无网络连接");
            builder.setMessage("是否打开网络设置?");
            builder.setPositiveButton("确认", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    MainActivity.this.startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
                }
            });
            builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    System.exit(1);
                    finish();
                }
            });
            builder.create().show();
            return  false;
        } else {
            return true;
        }
    }
    //获取物理接口ipv6地址
    public String getLocalIpAddress()
    {
        try {
            Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
            // 遍历所用的网络接口
            while (en.hasMoreElements()) {
                NetworkInterface nif = en.nextElement();// 得到每一个网络接口绑定的所有ip
                Enumeration<InetAddress> inet = nif.getInetAddresses();
                // 遍历每一个接口绑定的所有ip
                while (inet.hasMoreElements()) {
                    InetAddress ip = inet.nextElement();
                    if (!ip.isLoopbackAddress()) {
                        String strIP = ip.getHostAddress().toString();
                        if (!strIP.startsWith("fe80") && strIP.indexOf(':') != -1){//获取有效v6地址
                            int end = strIP.indexOf('%');
                            return strIP.substring(0,end);
                        }
                    }
                }
            }
        }
        catch (SocketException e)
        {
            Log.e("feige", "获取本地ip地址失败" + e);
            //e.printStackTrace();
        }
        return "";
    }
    //开启VPN
    public void openVPN(){
        Intent intent = VpnService.prepare(this);
        if (intent != null) {
            startActivityForResult(intent, 0);
        } else {
            onActivityResult(0, RESULT_OK, null);
        }
    }
    protected void onActivityResult(int request, int result, Intent data){
        if (result == RESULT_OK) {
            myVpnService.turnOn();
        }
    }
    //界面显示网络状态
    public void showData(){
        try{
            nowtime = d.format(new Date());
            duration = ((d.parse(nowtime)).getTime() - (d.parse(startTime)).getTime())/1000;
            hour = (int)duration / 3600;
            duration %= 3600;
            min = (int)duration / 60;
            duration %= 60;
            sec = (int)duration;

            viewTime.setText(Integer.toString(hour) + "时 " + Integer.toString(min) + "分 " + Integer.toString(sec) + "秒");
        } catch (ParseException e){
            Log.d("pe","Parse exception");
            viewTime.setText("0时 0分 0秒");
        }

        viewUpSpeed.setText(formatTraffic(upTraffic-tmp_upTraffic)+"/s");
        viewDownSpeed.setText(formatTraffic(downTraffic-tmp_downTraffic)+"/s");
        viewUpTraffic.setText(formatTraffic(upTraffic)+"/"+Long.toString(upPacket));
        viewDownTraffic.setText(formatTraffic(downTraffic)+"/"+Long.toString(downPacket));
        viewIPv4addr.setText(ipv4_addr);
        viewIPv6addr.setText(ipv6_addr);

    }
    //流量格式转换
    public String formatTraffic(long t){
        if (t < 1024){
            return Long.toString(t)+" bit";
        } else if (t < 1024*1024){
            return Long.toString(t/1024)+" KB";
        } else if (t < 1024*1024*1024){
            return Long.toString(t/1024/1024)+" MB";
        } else{
            return Long.toString(t/1024/1024/1024)+" GB";
        }
    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event){
        if (keyCode == KeyEvent.KEYCODE_BACK )//判断用户点击的是否为返回键
        {
            // 创建退出对话框
            AlertDialog isExit = new AlertDialog.Builder(this).create();
            // 设置对话框标题
            isExit.setTitle("系统提示");
            // 设置对话框消息
            isExit.setMessage("确定要退出吗");
            // 添加选择按钮并注册监听
            isExit.setButton("确定", listener);
            isExit.setButton2("取消", listener);
            // 显示对话框
            isExit.show();
        }
        return false;
    }
    DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener()
    {
        public void onClick(DialogInterface dialog, int which)
        {
            switch (which)
            {
                case AlertDialog.BUTTON_POSITIVE:// "确认"按钮退出程序
                    finish();
                    break;
                case AlertDialog.BUTTON_NEGATIVE:// "取消"第二个按钮取消对话框
                    break;
                default:
                    break;
            }
        }
    };

    @Override
    public void onDestroy(){//程序正常退出时，调用此函数，销毁管道
        super.onDestroy();

        if (myVpnService.file1.exists())
            myVpnService.file1.delete();
        if (file2.exists())
            file2.delete();
        System.exit(1);
    }

}
